import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_usb_printer/flutter_usb_printer.dart';

import '../../../../../../core/errors/printer_connection_exception.dart';
import '../../../../../../core/errors/printer_printing_exception.dart';

abstract class UsbDataSource {
  Future<List<Map<String, dynamic>>> getUsbDevices();
  Future<bool> connect(int vendorId, int productId);
  Future<bool> printBytes(List<int> bytes);
  Future<void> disconnect();
  Future<bool> isConnected();
}

/// USB ESC/POS printing via [FlutterUsbPrinter] (Android only — USB host
/// mode isn't available on iOS).
class UsbDataSourceImpl implements UsbDataSource {
  final FlutterUsbPrinter _printer = FlutterUsbPrinter();
  bool _connected = false;

  @override
  Future<List<Map<String, dynamic>>> getUsbDevices() async {
    if (!Platform.isAndroid) return [];
    try {
      final devices = await FlutterUsbPrinter.getUSBDeviceList();
      return devices.map((device) {
        final vendorId = int.tryParse('${device['vendorId']}') ?? 0;
        final productId = int.tryParse('${device['productId']}') ?? 0;
        final productName = (device['productName'] as String?)?.trim();
        final deviceName = (device['deviceName'] as String?)?.trim();
        final name = (productName != null && productName.isNotEmpty)
            ? productName
            : (deviceName != null && deviceName.isNotEmpty)
                ? deviceName
                : 'USB Printer';
        return <String, dynamic>{
          'vendorId': vendorId,
          'productId': productId,
          'name': name,
          'manufacturer': device['manufacturer'],
        };
      }).where((d) => d['vendorId'] != 0 || d['productId'] != 0).toList();
    } catch (e) {
      throw PrinterConnectionException('Failed to list USB devices.', cause: e);
    }
  }

  @override
  Future<bool> connect(int vendorId, int productId) async {
    try {
      final granted = await _printer.connect(vendorId, productId);
      _connected = granted ?? false;
      if (!_connected) {
        throw const PrinterConnectionException(
            'USB permission denied, or the printer is no longer connected.');
      }
      return true;
    } on PrinterConnectionException {
      rethrow;
    } catch (e) {
      _connected = false;
      throw PrinterConnectionException('Failed to connect to USB printer.', cause: e);
    }
  }

  @override
  Future<bool> printBytes(List<int> bytes) async {
    if (!_connected) {
      throw const PrinterConnectionException('USB printer is not connected.');
    }
    if (bytes.isEmpty) {
      throw const PrinterPrintingException('Cannot print empty data.');
    }
    try {
      final result = await _printer.write(Uint8List.fromList(bytes));
      return result ?? false;
    } catch (e) {
      throw PrinterPrintingException('Failed to print via USB.', cause: e);
    }
  }

  @override
  Future<void> disconnect() async {
    try {
      await _printer.close();
    } catch (_) {}
    _connected = false;
  }

  @override
  Future<bool> isConnected() async {
    try {
      return await _printer.isConnected();
    } catch (_) {
      return _connected;
    }
  }
}
